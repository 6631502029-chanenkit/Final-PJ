<?php 

    session_start();
    require_once 'config/db.php';

    if (isset($_POST['submit'])) {
        $user_id = $_POST['user_id'];
        $checkin = $_POST['checkin'];
        $checkout = $_POST['checkout'];
        $guests = $_POST['guests'];
        $room = $_POST['room'];

        // ตรวจสอบว่ากรอกข้อมูลครบหรือไม่
        if (empty($checkin)) {
            $_SESSION['error'] = 'กรุณากรอกวันที่เช็คอิน';
            header("location: user.php");
            exit();
        } else if (empty($checkout)) {
            $_SESSION['error'] = 'กรุณากรอกวันที่เช็คเอ้าท์';
            header("location: user.php");
            exit();
        } else if (empty($guests)) {
            $_SESSION['error'] = 'กรุณาเลือกจำนวนผู้เข้าพัก';
            header("location: user.php");
            exit();
        } else if (empty($room)) {
            $_SESSION['error'] = 'กรุณาเลือกห้องพัก';
            header("location: user.php");
            exit();
        } else {
            try {
                // ตรวจสอบว่าวันที่เช็คอิน ต้องน้อยกว่าเช็คเอ้าท์
                if (strtotime($checkin) >= strtotime($checkout)) {
                    $_SESSION['error'] = 'วันที่เช็คเอ้าท์ต้องมากกว่าวันที่เช็คอิน';
                    header("location: user.php");
                    exit();
                }
                
                // ดึงข้อมูล firstname จาก account
                $account_stmt = $conn->prepare("SELECT firstname FROM account WHERE id_account = :user_id");
                $account_stmt->bindParam(":user_id", $user_id);
                $account_stmt->execute();
                $account_row = $account_stmt->fetch(PDO::FETCH_ASSOC);
                $firstname = $account_row['firstname'];
                
                // ดึง room_id จาก room table
                $room_stmt = $conn->prepare("SELECT room_id FROM room WHERE room_number = :room_number");
                $room_stmt->bindParam(":room_number", $room);
                $room_stmt->execute();
                $room_row = $room_stmt->fetch(PDO::FETCH_ASSOC);
                $room_id = $room_row['room_id'];
                
                // บันทึกข้อมูลการจอง
                $insert = $conn->prepare("INSERT INTO booking_info (user_id, name_id, room_count, member, check_in, check_out) VALUES (:user_id, :name_id, :room_count, :member, :check_in, :check_out)");
                $insert->bindParam(":user_id", $user_id);
                $insert->bindParam(":name_id", $firstname);
                $insert->bindParam(":room_count", $room_id);
                $insert->bindParam(":member", $guests);
                $insert->bindParam(":check_in", $checkin);
                $insert->bindParam(":check_out", $checkout);
                
                if ($insert->execute()) {
                    // อัพเดต room_status เป็น 1 (ห้องเต็ม) เมื่อมีการจองสำเร็จ
                    $update_room = $conn->prepare("UPDATE room SET room_status = 1 WHERE room_id = :room_id");
                    $update_room->bindParam(":room_id", $room_id);
                    $update_room->execute();
                    
                    $_SESSION['success'] = 'จองห้องพักสำเร็จ';
                    header("location: user.php");
                    exit();
                }

            } catch(PDOException $e) {
                $_SESSION['error'] = 'เกิดข้อผิดพลาด: ' . $e->getMessage();
                header("location: user.php");
                exit();
            }
        }
    }

?>
