<?php 
  session_start();
  require_once 'config/db.php';
  if (!isset($_SESSION['id_account'])) {
      $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
      header('location: signin.php');
  }

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="user.css">
</head>

<body>
  <div class="top-left-bar">
    <?php 
      if (isset($_SESSION['id_account'])) {
          $user_id = $_SESSION['id_account'];
          $stmt = $conn->prepare("SELECT * FROM account WHERE id_account = :id");
          $stmt->bindParam(":id", $user_id);
          $stmt->execute();
          $row = $stmt->fetch(PDO::FETCH_ASSOC);
        }
      ?>
      <h3 class="mt-4">Welcome User, <?php echo $row['firstname'] . ' ' . $row['lastname'] ?> 
      <a href="logout.php" class="btn btn-danger">Logout</a></h3>
    </div>

    <!-- Error/Success Message -->
    <?php if(isset($_SESSION['error'])) { ?>
      <div class="alert alert-danger" role="alert" style="margin-top: 80px;">
          <?php 
              echo $_SESSION['error'];
              unset($_SESSION['error']);
          ?>
      </div>
    <?php } ?>
    <?php if(isset($_SESSION['success'])) { ?>
      <div class="alert alert-success" role="alert" style="margin-top: 80px;">
          <?php 
              echo $_SESSION['success'];
              unset($_SESSION['success']);
          ?>
      </div>
    <?php } ?>

    <!-- Booking History Bar -->
    <div class="booking-history-bar">
      <h5>📋 ประวัติการจอง</h5>
      <?php 
        if (isset($_SESSION['id_account'])) {
            $user_id = $_SESSION['id_account'];
            $firstname = $row['firstname'];
            
            // ดึงข้อมูลการจองจาก database
            $booking_stmt = $conn->prepare("SELECT * FROM booking_info WHERE user_id = :user_id AND name_id = :name_id");
            $booking_stmt->bindParam(":user_id", $user_id);
            $booking_stmt->bindParam(":name_id", $firstname);
            $booking_stmt->execute();
            
            if ($booking_stmt->rowCount() > 0) {
                echo '<table class="table table-sm table-striped">';
                echo '<thead><tr><th>ห้อง</th><th>Check-in</th><th>Check-out</th><th>จำนวนคน</th><th>จัดการ</th></tr></thead>';
                echo '<tbody>';
                
                while ($booking_row = $booking_stmt->fetch(PDO::FETCH_ASSOC)) {
                    // ดึงเลขห้องจาก room table ด้วย room_id
                    $room_detail_stmt = $conn->prepare("SELECT room_number FROM room WHERE room_id = :room_id");
                    $room_detail_stmt->bindParam(":room_id", $booking_row['room_count']);
                    $room_detail_stmt->execute();
                    $room_detail = $room_detail_stmt->fetch(PDO::FETCH_ASSOC);
                    $room_number = $room_detail['room_number'];
                    
                    echo '<tr>';
                    echo '<td>ห้อง ' . $room_number . '</td>';
                    echo '<td>' . $booking_row['check_in'] . '</td>';
                    echo '<td>' . $booking_row['check_out'] . '</td>';
                    echo '<td>' . $booking_row['member'] . ' คน</td>';
                    echo '<td><a href="cancel_booking.php?booking_id=' . $booking_row['booking_id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'ยืนยันการยกเลิก?\')">ยกเลิก</a></td>';
                    echo '</tr>';
                }
                
                echo '</tbody></table>';
            } else {
                echo '<div class="alert alert-info">ไม่มีประวัติการจอง</div>';
            }
        }
      ?>
    </div>

    <!-- Booking Form -->
    <div class="booking-form">
      <h4>📅 จองห้องพัก</h4>
      <form action="booking_db.php" method="POST">

        <!-- วันที่เช็คอิน -->
        <div class="mb-3">
          <label for="checkin" class="form-label">วันที่เช็คอิน</label>
          <input type="date" class="form-control" id="checkin" name="checkin" required>
        </div>

        <!-- วันที่เช็คเอ้าท์ -->
        <div class="mb-3">
          <label for="checkout" class="form-label">วันที่เช็คเอ้าท์</label>
          <input type="date" class="form-control" id="checkout" name="checkout" required>
        </div>

        <!-- จำนวนผู้เข้าพัก -->
        <div class="mb-3">
          <label for="guests" class="form-label">จำนวนผู้เข้าพัก</label>
          <select class="form-select" id="guests" name="guests" required>
            <option value="" disabled selected>-- เลือกจำนวนคน --</option>
            <option value="1">1 คน</option>
            <option value="2">2 คน</option>
          </select>
        </div>

        <!-- เลือกห้องพัก -->
        <div class="mb-4">
          <label for="room" class="form-label">เลือกห้องพัก</label>
          <select class="form-select" id="room" name="room" required>
            <option value="" disabled selected>-- เลือกห้อง --</option>
            <option value="101">ห้อง 101</option>
            <option value="102">ห้อง 102</option>
            <option value="103">ห้อง 103</option>
            <option value="104">ห้อง 104</option>
            <option value="105">ห้อง 105</option>
            <option value="106">ห้อง 106</option>
          </select>
        </div>

        <!-- Hidden: ส่ง user id ไปด้วย -->
        <input type="hidden" name="user_id" value="<?php echo $_SESSION['id_account']; ?>">
        <button type="submit" name="submit" class="btn btn-primary">ยืนยันการจอง</button>
      </form>
    </div>

  </body>
</html>